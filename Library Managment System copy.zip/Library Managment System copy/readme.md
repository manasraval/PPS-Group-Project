This code was written by 
{Dhruv Bharara , Registration Number - RA2111050010033} ; 
{Pritesh Panda , Registration Number - RA2111050010034} ; 
{Manas Raval , Registration Number - RA2111050010035} ; 
{Advaith Hanumanchi , Registration Number - RA2111050010038} 
of section Q1 Project is on Library Management System written in C language.